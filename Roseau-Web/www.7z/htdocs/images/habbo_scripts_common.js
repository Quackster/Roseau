function openClient()
{
	client = window.open("", "client", "width=720,height=540");
}

function openPopup(width,height,name)
{
	if (!width) width = 720;
	if (!height) height = 540;
	if (!name) name = "habbopopup";
	
	client = window.open("", name, "width="+width+",height="+height);
}

/*
     FILE ARCHIVED ON 16:54:20 Apr 12, 2003 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 06:47:42 Mar 31, 2017.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/